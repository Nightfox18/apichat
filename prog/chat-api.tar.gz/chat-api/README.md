# Chat API

REST API для управления чатами и сообщениями, построенный на FastAPI + PostgreSQL.

## 📋 Описание

API предоставляет следующие возможности:
- Создание чатов с заголовками
- Отправка сообщений в чаты
- Получение чата с историей сообщений (с пагинацией)
- Удаление чатов (с каскадным удалением сообщений)

## 🛠 Технологический стек

- **Backend**: FastAPI 0.109.0
- **Database**: PostgreSQL 15 + SQLAlchemy 2.0 (async)
- **ORM**: SQLAlchemy с asyncpg драйвером
- **Validation**: Pydantic 2.5
- **Migrations**: Alembic
- **Testing**: pytest + pytest-asyncio
- **Containerization**: Docker + docker-compose

## 📁 Структура проекта

```
chat-api/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI приложение
│   ├── config.py            # Конфигурация
│   ├── database.py          # Async SQLAlchemy setup
│   ├── exceptions.py        # Кастомные исключения
│   ├── models/              # SQLAlchemy модели
│   │   └── chat.py
│   ├── schemas/             # Pydantic схемы
│   │   └── chat.py
│   ├── services/            # Бизнес-логика
│   │   └── chat_service.py
│   └── routers/             # API endpoints
│       └── chats.py
├── alembic/                 # Миграции БД
│   ├── versions/
│   │   └── 001_initial.py
│   └── env.py
├── tests/                   # Тесты
│   ├── conftest.py
│   ├── test_chats.py
│   └── test_validation.py
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
├── alembic.ini
├── pytest.ini
└── README.md
```

## 🚀 Быстрый старт

### Предварительные требования

- Docker >= 20.10
- docker-compose >= 1.29

### Запуск проекта

1. **Клонируйте репозиторий:**
   ```bash
   git clone <repository-url>
   cd chat-api
   ```

2. **Создайте файл `.env` (опционально):**
   ```bash
   cp .env.example .env
   ```
   
   По умолчанию используются настройки из `docker-compose.yml`.

3. **Запустите приложение:**
   ```bash
   docker-compose up --build
   ```
   
   Это автоматически:
   - Запустит PostgreSQL
   - Создаст базу данных
   - Применит миграции Alembic
   - Запустит FastAPI приложение

4. **Приложение доступно по адресу:**
   - API: http://localhost:8000
   - Swagger UI (интерактивная документация): http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

### Остановка приложения

```bash
docker-compose down
```

Для удаления volumes (БД):
```bash
docker-compose down -v
```

## 📚 API Endpoints

### 1. Создать чат
**POST** `/chats/`

**Request Body:**
```json
{
  "title": "General Chat"
}
```

**Response (201):**
```json
{
  "id": 1,
  "title": "General Chat",
  "created_at": "2026-02-04T10:30:00Z"
}
```

**Валидация:**
- `title`: 1-200 символов, обязательное поле
- Пробелы по краям автоматически удаляются

---

### 2. Отправить сообщение
**POST** `/chats/{chat_id}/messages/`

**Request Body:**
```json
{
  "text": "Hello, world!"
}
```

**Response (201):**
```json
{
  "id": 1,
  "chat_id": 1,
  "text": "Hello, world!",
  "created_at": "2026-02-04T10:31:00Z"
}
```

**Валидация:**
- `text`: 1-5000 символов, обязательное поле
- Пробелы по краям автоматически удаляются

**Ошибки:**
- `404`: Чат не найден

---

### 3. Получить чат с сообщениями
**GET** `/chats/{chat_id}?limit=20&offset=0`

**Query Parameters:**
- `limit` (optional): количество сообщений (1-100, по умолчанию 20)
- `offset` (optional): пропустить N сообщений (по умолчанию 0)

**Response (200):**
```json
{
  "id": 1,
  "title": "General Chat",
  "created_at": "2026-02-04T10:30:00Z",
  "messages": [
    {
      "id": 3,
      "chat_id": 1,
      "text": "Latest message",
      "created_at": "2026-02-04T10:33:00Z"
    },
    {
      "id": 2,
      "chat_id": 1,
      "text": "Second message",
      "created_at": "2026-02-04T10:32:00Z"
    }
  ]
}
```

**Особенности:**
- Сообщения отсортированы по `created_at` **DESC** (новые первыми)
- Поддержка пагинации через `limit` и `offset`

**Ошибки:**
- `404`: Чат не найден
- `422`: Некорректные параметры (limit вне диапазона 1-100)

---

### 4. Удалить чат
**DELETE** `/chats/{chat_id}`

**Response (204):**
```
No Content
```

**Особенности:**
- Каскадное удаление: все сообщения чата удаляются автоматически

**Ошибки:**
- `404`: Чат не найден

---

### 5. Health Check
**GET** `/health`

**Response (200):**
```json
{
  "status": "healthy",
  "service": "chat-api"
}
```

## 🧪 Тестирование

### Запуск тестов

```bash
# В контейнере
docker-compose exec app pytest

# Локально (требуется установка зависимостей)
pytest
```

### Запуск с покрытием

```bash
docker-compose exec app pytest --cov=app --cov-report=html
```

### Структура тестов

- **Integration тесты** (`tests/test_chats.py`):
  - Тестирование всех API endpoints
  - Проверка валидации, пагинации, каскадного удаления
  - Покрытие edge-cases (пустые строки, лимиты длины, 404 ошибки)

- **Unit тесты** (`tests/test_validation.py`):
  - Тестирование Pydantic схем в изоляции
  - Проверка trimming, валидаторов, границ длины

## 🗄 База данных

### Схема БД

```sql
-- Таблица чатов
CREATE TABLE chats (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Таблица сообщений
CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    text VARCHAR(5000) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Индексы
CREATE INDEX idx_chats_created_at ON chats(created_at);
CREATE INDEX idx_messages_chat_id ON messages(chat_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
```

### Миграции

Миграции применяются автоматически при запуске через `docker-compose up`.

**Ручное управление миграциями:**

```bash
# Применить миграции
docker-compose exec app alembic upgrade head

# Откатить миграции
docker-compose exec app alembic downgrade -1

# Создать новую миграцию
docker-compose exec app alembic revision --autogenerate -m "description"
```

## 🔧 Разработка

### Локальная разработка без Docker

1. **Установите зависимости:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Настройте PostgreSQL:**
   ```bash
   # Создайте БД
   createdb chatdb
   
   # Обновите .env
   DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/chatdb
   ```

3. **Примените миграции:**
   ```bash
   alembic upgrade head
   ```

4. **Запустите приложение:**
   ```bash
   uvicorn app.main:app --reload
   ```

### Переменные окружения

| Переменная | Описание | По умолчанию |
|-----------|----------|--------------|
| `DATABASE_URL` | URL подключения к PostgreSQL | `postgresql+asyncpg://chatuser:chatpass@db:5432/chatdb` |
| `LOG_LEVEL` | Уровень логирования | `INFO` |
| `APP_HOST` | Хост приложения | `0.0.0.0` |
| `APP_PORT` | Порт приложения | `8000` |

## 📝 Логирование

Приложение использует структурированное логирование:

- **Startup/Shutdown**: Информация о запуске и остановке
- **Requests**: Логирование всех HTTP запросов
- **Errors**: Детальное логирование ошибок с трассировкой

Пример:
```
2026-02-04 10:30:00 - app.main - INFO - Starting Chat API application...
2026-02-04 10:30:01 - app.main - INFO - POST /chats/
2026-02-04 10:30:01 - app.main - INFO - Response status: 201
```

## 🐛 Обработка ошибок

API возвращает структурированные ответы для всех ошибок:

**404 Not Found:**
```json
{
  "detail": "Chat with id 123 not found"
}
```

**422 Validation Error:**
```json
{
  "detail": [
    {
      "loc": ["body", "title"],
      "msg": "Title cannot be empty or only whitespace",
      "type": "value_error"
    }
  ]
}
```

**500 Internal Server Error:**
```json
{
  "detail": "Internal server error"
}
```

## ✅ Критерии соответствия ТЗ

- ✅ FastAPI + PostgreSQL + SQLAlchemy ORM
- ✅ Async SQLAlchemy 2.0 с asyncpg
- ✅ Все 4 endpoint'а реализованы согласно спецификации
- ✅ Валидация входных данных (Pydantic)
- ✅ Trimming пробелов для title и text
- ✅ Каскадное удаление на уровне БД (`ON DELETE CASCADE`)
- ✅ Пагинация с limit (1-100)
- ✅ Сортировка сообщений по `created_at DESC`
- ✅ Миграции Alembic
- ✅ Docker + docker-compose
- ✅ Структурированная архитектура (models/schemas/services/routers)
- ✅ Логирование
- ✅ Тесты (pytest): integration и unit
- ✅ Типизация (type hints)

## 🎯 Производительность

### Оптимизации:

1. **Индексы БД**:
   - `idx_chats_created_at` — для сортировки чатов
   - `idx_messages_chat_id` — для быстрого поиска сообщений по chat_id
   - `idx_messages_created_at` — для сортировки сообщений

2. **Async/Await**:
   - Полностью асинхронный стек (FastAPI + asyncpg)
   - Параллельная обработка запросов

3. **Ленивая загрузка**:
   - Сообщения загружаются только при необходимости
   - Пагинация на уровне БД (LIMIT/OFFSET)

## 📄 Лицензия

MIT License

## 👨‍💻 Автор

Тестовое задание для позиции Python Developer
