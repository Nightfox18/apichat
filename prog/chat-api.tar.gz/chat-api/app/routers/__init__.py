"""
API routers package.
"""
from app.routers.chats import router as chats_router

__all__ = ["chats_router"]
