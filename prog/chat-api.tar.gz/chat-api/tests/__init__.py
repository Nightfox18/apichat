"""
Tests package for Chat API.
"""
